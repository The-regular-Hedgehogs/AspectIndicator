## 1.0.2

- Changed Changelog order + Edited description + Added missing Dependency

## 1.0.1

- Added GIF & Images / Fixed formatting in README.md

## 1.0.0

- First release