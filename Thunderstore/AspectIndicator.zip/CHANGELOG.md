## 1.0.0

- First release

## 1.0.1

- Added GIF & Images / Fixed formatting in README.md